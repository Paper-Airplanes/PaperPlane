#version 330 core

void main()
{             
    // do nothing
}